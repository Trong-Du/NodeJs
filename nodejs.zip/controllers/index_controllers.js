const express = require('express');
const router = express.Router();

// Gọi admin
const admin_controllers = require('./admin_controllers');
router.use('/', admin_controllers);

// Gọi product
const product_controllers = require('./product_controllers');
router.use('/', product_controllers);

// Gọi user
const user_controllers = require('./user_controllers');
router.use('/', user_controllers);

module.exports = router;