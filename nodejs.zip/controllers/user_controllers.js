const express = require('express');
const router = express.Router();

// Gọi model
const UserModels = require('../models/user_models');

router.get('/user', (req, res)=>{

    link=req.originalUrl;

    main = 'users/main';

    UserModels.find()
    .exec((err, data)=>{
        if(err){
            res.send({kq: 0, err: err})
        }else{

            str='';

            data.forEach((v)=>{

                str += `<tr>
                <td>` + v.name + `</td>
                <td>Doe</td>
                <td>
                    <a href="product/edit/5" class="btn btn-info">
                        Sửa
                    </a>  
                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModal">
                        Xóa
                    </button>
                </td>
                </tr>`;

            });

            // Gọi view
            res.render('index', {main: main, link:link, str:str});
        }
    });
});

router.get('/user/add', (req, res)=>{
    main = 'users/add';

    // Gọi view
    res.render('index', {main: main});
});

// Xuất dữ liệu
module.exports = router;