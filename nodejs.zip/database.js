// gọi mongoose
const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://phuoc:yOnJyFM5xvkz7q2v@cluster0.nmruj.mongodb.net/mean5102020?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true
})
// thành công
.then( () => console.log('Kết nối DB thành công') )
// thất bại, báo lỗi
.catch( (err) => console.log(err) );